/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import view.TelaMenuProfessor;

/**
 *
 * @author Philipe
 */
public class MenuProfessorController {
    private TelaMenuProfessor view; 
            
    public MenuProfessorController(TelaMenuProfessor view){
       this.view = view;
       view.setVisible(true);
    }        
    
    

   
}
