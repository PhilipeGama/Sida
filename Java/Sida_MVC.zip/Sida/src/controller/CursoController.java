package controller;

import dao.CursoDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Curso;
import view.TelaCurso;

public class CursoController {

    private TelaCurso view;
    private ArrayList<Curso> listaBeans;
    private int index;
    private int op;
    
    public CursoController(TelaCurso view) {
        this.view = view;
        this.view.addBtnPesquisarListener(new BtnPesquisarListener());
        this.view.addTblProdutoListener(new TableMouseListener());
        this.view.addBtnNovoListener(new BtnNovoListener());
        this.view.addBtnSalvarListener(new BtnSalvarListener());
        this.view.addBtnExcluirListener(new BtnExcluirListener());
        this.view.addBtnCancelarListener(new BtnCancelarListener());
        carregaTabela();
        this.view.setVisible(true);
    }
    
    private void carregaTabela(){
        try {
                CursoDAO dao = new CursoDAO();
                listaBeans = dao.consultarDescricao(view.getTxtPesquisar());
                
                Vector linhas = new Vector();
                Vector colunas = new Vector();                
                colunas.add("Sigla");
                colunas.add("Descrição");

                for (Curso bean : listaBeans) {
                    Vector linha = new Vector();
                    linha.add(bean.getSigla());
                    linha.add(bean.getDescricao());
                    linhas.add(linha);
                }
                          
                DefaultTableModel model = new DefaultTableModel(linhas, colunas);
                view.setTblProduto(model);
            } catch (Exception ex) {
                Logger.getLogger(CursoController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    private void atualizaBtn(boolean ok){
        view.btnNovoEnabled(ok);
        view.btnSalvarEnabled(ok);
        view.btnExcluirEnabled(ok);
        view.btnCancelarEnabled(ok);
    }
    
    private void atualizaCampos(boolean ok){
       view.txtDescricaoEnabled(ok);
       view.txtSiglaEnabled(ok);
       
      
    }
    
    private void limpaCampos(){
        view.setTxtDescricao("");
        view.setTxtSigla("");
    }
    
    private class BtnNovoListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            op = 0;
            atualizaBtn(false);
            view.btnSalvarEnabled(true);
            view.btnCancelarEnabled(true);
            atualizaCampos(true);
        }
        
    }
    
    private class BtnSalvarListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            // verifica se todos os campos est�o preenchidos
            if(!view.getTxtDescricao().trim().isEmpty() &&
               !view.getTxtSigla().trim().isEmpty() ){
                
                    //caso op seja igual a 0, cadastra o produto
                    if(op  == 0){
                        Curso bean = new Curso();
                        bean.setSigla(view.getTxtSigla());
                        bean.setDescricao(view.getTxtDescricao());
                        
                        try { 
                            CursoDAO dao = new CursoDAO();
                            boolean ok = dao.cadastrar(bean);
                            if(ok){
                                view.showMsg("Curso cadastrado!");
                                atualizaBtn(false);
                                view.btnNovoEnabled(true);
                                limpaCampos();
                                atualizaCampos(false);
                            }else{
                                view.showMsg("Erro ao cadastrar curso!");
                            }                           
                        } catch (Exception ex) {
                            Logger.getLogger(CursoController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        
                    //caso seja diferente de 0, atualiza o produto
                    }else{
                        Curso bean = listaBeans.get(index);
                        //bean.setSigla(view.getTxtSigla());
                        bean.setDescricao(view.getTxtDescricao());
                try {
                            CursoDAO dao = new CursoDAO();
                            boolean ok = dao.alterar(bean);
                            if(ok){
                                view.showMsg("Curso atualizado!");
                                atualizaBtn(false);
                                view.btnNovoEnabled(true);
                                limpaCampos();
                                atualizaCampos(false);
                            }else{
                                view.showMsg("Erro ao atualizar curso!");
                            }  
                            
                        } catch (Exception ex) {
                            Logger.getLogger(CursoController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        
                    }
                    //atualiza a tabela
                    carregaTabela();
            }else{                    
                view.showMsg("Preencha todos os campos!");
            }         
        }
        
    }
    
    private class BtnExcluirListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            int op = JOptionPane.showConfirmDialog(null, "Deseja proseguir?", "Selecione a opção desejada: ",JOptionPane.YES_NO_OPTION);
            Curso curso = listaBeans.get(index);
        if(op == 0){
            try {
                CursoDAO dao = new CursoDAO();
                
                boolean ok = dao.excluir(curso.getSigla());
                if(ok){
                    JOptionPane.showMessageDialog(null, "Curso Excluido!");
                    carregaTabela();
                    limpaCampos();
                    atualizaCampos(false);
                    atualizaBtn(false);
                    view.btnNovoEnabled(true);
                }
            } catch (Exception ex) {
                view.showMsg("Erro ao excluir curso!");
            }
        }
        }
        
    }
    
    private class BtnCancelarListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            limpaCampos();
            atualizaCampos(false);
            atualizaBtn(false);
            view.btnNovoEnabled(true);
        }
        
    }
    
    private class BtnPesquisarListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            carregaTabela();        
        }
        
    }
    
    private class TableMouseListener implements MouseListener{
        @Override
        public void mouseClicked(MouseEvent e) {
            index = view.getTableCursor();
            Curso bean = listaBeans.get(index);
            view.setTxtDescricao(bean.getDescricao());
            view.setTxtSigla("" + bean.getSigla());
            view.setTxtDescricao("" + bean.getDescricao());        
            atualizaBtn(true);
            view.btnNovoEnabled(false);
            atualizaCampos(true);
            op = 1;
        }

        @Override
        public void mousePressed(MouseEvent e) {}

        @Override
        public void mouseReleased(MouseEvent e) {}

        @Override
        public void mouseEntered(MouseEvent e) {}

        @Override
        public void mouseExited(MouseEvent e) {}
        
    }
    
}
