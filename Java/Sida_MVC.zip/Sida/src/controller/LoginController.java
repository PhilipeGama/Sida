package controller;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import dao.AdministradorDAO;
import dao.ProfessorDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Administrador;
import view.TelaLogin;
import view.TelaMenuAdministrador;
import view.TelaMenuProfessor;


/**
 *
 * @author Aluno
 */
public class LoginController {
    private TelaLogin tela;
    
    
    public LoginController(TelaLogin tela) {
        this.tela = tela;
        this.tela.addBtnEntrarListener(new entrar());
        this.tela.setVisible(true);
    }   
    public class entrar implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            String login = tela.getTxtLogin();
            String senha = tela.getTxtSenha();
            if(!login.equals("") && !senha.equals("")){
                if(tela.btnAdministradorIsSelected()){
                    
                        try {
                            AdministradorDAO dao = new AdministradorDAO();
                            int ok = dao.login(login, senha);
                            if(ok != 0){
                                new MenuAdministradorController(new TelaMenuAdministrador());  
                                tela.closeView();
                            }else{
                                tela.showMsg("Login e/ou senha incorretos!");
                            }                        
                        } catch (Exception ex) {
                            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    
                    
                }else if(tela.btnProfessorIsSelected()){
                    if(isStringOnlyAlphabet(login)){
                        try {
                            ProfessorDAO dao = new ProfessorDAO();
                            int ok = dao.login(login, senha);
                            if(ok != 0){
                                new MenuProfessorController(new TelaMenuProfessor()); 
                                tela.closeView();
                            }else{
                                tela.showMsg("Login e/ou senha incorretos!");
                            }            
                        } catch (Exception ex) {
                            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                        }     
                    }
                    else{
                        tela.showMsg("Insira uma matrícula numérica!");
                    }
                    
                }
            }
        }        
    }
    
    public boolean isStringOnlyAlphabet(String str){ 
        return ((!str.equals("")) 
                && (str != null) 
                && (str.matches("[0-9]+") && str.length() > 2)); 
    } 
}
