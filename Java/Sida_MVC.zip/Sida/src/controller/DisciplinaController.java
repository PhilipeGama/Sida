package controller;

import view.TelaDisciplina;
import dao.CursoDAO;
import dao.DisciplinaCursoDAO;
import dao.DisciplinaDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Curso;
import model.Disciplina;
import model.DisciplinaCurso;
import mvc.RunTelaDisciplina;
import view.TelaListaCurso;


public class DisciplinaController {

    private TelaDisciplina view;
    private ArrayList<Disciplina> listaBeans1;
    //private ArrayList<Curso> listaBeans2; // verificao curso e valido
    private ArrayList<Curso> listaBeans3 = new ArrayList<>(); // adicionar curso
    private int indexTable,indexCbox;
    public static String codigoDisc;
    
    private int op;
    
    public DisciplinaController(TelaDisciplina view) {
        this.view = view;
        this.view.addBtnPesquisarListener(new BtnPesquisarListener());
        this.view.addTblProdutoListener(new TableMouseListener());
        this.view.addBtnNovoListener(new BtnNovoListener());
        this.view.addBtnSalvarListener(new BtnSalvarListener());
        this.view.addBtnExcluirListener(new BtnExcluirListener());
        this.view.addBtnCancelarListener(new BtnCancelarListener());
        this.view.addBtnPesquisarCurso(new BtnAdicionarCursoListener());
        this.view.addCbxListener(new ComboBoxMouseListener());
        listaBeans3 = new ArrayList<>();
        carregaTabela();
        this.view.setVisible(true);
    }

    public DisciplinaController() {
    }
        
    public void adicionarComboBox(String sigla){
        if(view.checkIfIsTheSame(sigla)){
            view.showMsg("Disciplina já adicionada!");
        }else{
            view.addItemComboBox(sigla);
        }
    }
    
    public void adicionarListaBeans3(Curso c){
        listaBeans3.add(c);
    }
    
    
    
    private void carregaTabela(){
        try {
               DisciplinaDAO dao = new DisciplinaDAO();
               listaBeans1 = dao.consultarDescricao(view.getTxtPesquisar());
                
                Vector linhas = new Vector();
                Vector colunas = new Vector();                
                colunas.add("Sigla");
                colunas.add("Descrição");
                colunas.add("Carga Horaria");
                

                for (Disciplina bean : listaBeans1) {
                    Vector linha = new Vector();
                    linha.add(bean.getSigla());
                    linha.add(bean.getDescricao());
                    linha.add(bean.getCargahoraria());
                    linhas.add(linha);
                }
                          
                DefaultTableModel model = new DefaultTableModel(linhas, colunas);
                view.setTblProduto(model);
            } catch (Exception ex) {
                Logger.getLogger(DisciplinaController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    private void atualizaBtn(boolean ok){
        view.btnNovoEnabled(ok);
        view.btnSalvarEnabled(ok);
        view.btnExcluirEnabled(ok);
        view.btnCancelarEnabled(ok);
    }
    
    private void atualizaCampos(boolean ok){
        view.txtSiglaEnabled(ok);
        view.txtDescricaoEnabled(ok);
        view.txtCargaHorariaEnabled(ok);
    }
    
    private void limpaCampos(){
        view.setTxtDescricao("");
        view.setTxtSigla("");
        view.setTxtCargaHoraria("");
    }
    
    private class BtnNovoListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            op = 0;
            atualizaBtn(false);
            view.btnSalvarEnabled(true);
            view.btnCancelarEnabled(true);
            atualizaCampos(true);
        }
        
    }
    
    private class BtnSalvarListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            // verifica se todos os campos est�o preenchidos
            if(!view.getTxtDescricao().trim().isEmpty() &&
               !view.getTxtSigla().trim().isEmpty() &&
                    !view.getTxtCargaHoraria().trim().isEmpty()){
                
                    //caso op seja igual a 0, cadastra o disciplina
                    if(op  == 0){
                        Disciplina bean = new Disciplina();
                        bean.setSigla(view.getTxtSigla());
                        bean.setDescricao(view.getTxtDescricao());
                        
                        try {
                            bean.setCargahoraria(Double.parseDouble(view.getTxtCargaHoraria()));
                        }catch (NumberFormatException ex) {
                            System.out.println(ex);
                               System.out.println("aa");
                        }
                        
                        //bean.setCurso(listaBeansCbx.get(indexCbox));
                      
                            DisciplinaDAO dao = null;
                        try {
                            dao = new DisciplinaDAO();
                        } catch (Exception ex) {
                            Logger.getLogger(DisciplinaController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                            boolean ok = dao.cadastrar(bean);
                            DisciplinaCursoDAO dao2 = null;
                            try {
                                dao2 = new DisciplinaCursoDAO();
                            } catch (Exception ex) {
                                Logger.getLogger(DisciplinaController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            DisciplinaCurso dc = new DisciplinaCurso();
                            dc.setDissigla(bean.getSigla());
                            
                            for (Curso curso : listaBeans3) {
                            
                                dc.setCursigla(curso.getSigla());
                                 System.out.println(dc.toString());
                                dao2.addDisciplina(dc);
                            }    
                            if(ok){
                                view.showMsg("Disciplina cadastrada!");
                                atualizaBtn(false);
                                view.btnNovoEnabled(true);
                                limpaCampos();
                                atualizaCampos(false);
                            }else{
                                view.showMsg("Erro ao cadastrar disciplina!");
                            }                           
                       
                        
                        
                    //caso seja diferente de 0, atualiza o disciplina
                        
                    //caso seja diferente de 0, atualiza o disciplina
                    }else{
                        Disciplina bean = listaBeans1.get(indexTable);
                        bean.setSigla(view.getTxtSigla());
                        bean.setDescricao(view.getTxtDescricao());
                        
                        try {
                            bean.setCargahoraria(Double.parseDouble(view.getTxtCargaHoraria()));
                            
                        }catch (NumberFormatException ex) {
                            System.out.println(ex);
                        }
                      
                try {
                            DisciplinaDAO dao = new DisciplinaDAO();
                            boolean ok = dao.cadastrar(bean);
                            if(ok){
                                view.showMsg("Produto atualizado!");
                                atualizaBtn(false);
                                view.btnNovoEnabled(true);
                                limpaCampos();
                                atualizaCampos(false);
                            }else{
                                view.showMsg("Erro ao atualizar disciplina!");
                            }  
                            
                        } catch (Exception ex) {
                            System.out.println(ex);
                        }
                        
                    }
                    //atualiza a tabela
                    carregaTabela();
            }else{                    
                view.showMsg("Preencha todos os campos!");
            }         
        }
        
    }
    
    private class BtnExcluirListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            int op = JOptionPane.showConfirmDialog(null, "Deseja proseguir?", "Selecione a opção",JOptionPane.YES_NO_OPTION);
            Disciplina bean = listaBeans1.get(indexTable);
        if(op == 0){
            try {
                DisciplinaDAO dao = new DisciplinaDAO();
                
                boolean ok = dao.excluir(bean.getSigla());
                if(ok){
                    carregaTabela();
                    JOptionPane.showMessageDialog(null, "Disciplina Excluido!");
                    
                    limpaCampos();
                    atualizaCampos(false);
                    atualizaBtn(false);
                    view.btnNovoEnabled(true);
                }
            } catch (Exception ex) {
                view.showMsg("Erro ao excluir disciplina!");
            }
        }
        }
        
    }
    
    private class BtnCancelarListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            limpaCampos();
            atualizaCampos(false);
            atualizaBtn(false);
            view.btnNovoEnabled(true);
        }
        
    }
    
    private class BtnPesquisarListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
            carregaTabela();        
        }
        
    }
    
    private class TableMouseListener implements MouseListener{
        @Override
        public void mouseClicked(MouseEvent e) {
            indexTable = view.getTableCursor();
            Disciplina bean = listaBeans1.get(indexTable);
            view.setTxtSigla(bean.getSigla());
            view.setTxtDescricao(bean.getDescricao());
            view.setTxtCargaHoraria(Double.toString(bean.getCargahoraria()));
            view.setTxtDescricao("" + bean.getDescricao());        
            atualizaBtn(true);
            view.btnNovoEnabled(false);
            atualizaCampos(true);
            
            op = 1;
        }

        @Override
        public void mousePressed(MouseEvent e) {}

        @Override
        public void mouseReleased(MouseEvent e) {}

        @Override
        public void mouseEntered(MouseEvent e) {}

        @Override
        public void mouseExited(MouseEvent e) {}
        
    }
    
    private class ComboBoxMouseListener implements MouseListener{
        
        @Override
        public void mouseClicked(MouseEvent e) {
            indexCbox = view.getComboBoxCursor();
            
        }

        @Override
        public void mousePressed(MouseEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void mouseExited(MouseEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    
    } 
    
    private class  BtnAdicionarCursoListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            //RunTelaDisciplina run1 = new RunTelaDisciplina();
            new ListaCursoController(new TelaListaCurso(), DisciplinaController.this);
            
        }
    
    }
    
   
}
