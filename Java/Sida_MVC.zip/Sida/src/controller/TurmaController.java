
package controller;

import view.TelaTurma;

/**
 *
 * @author philipe.gama
 */
public class TurmaController {
    public TurmaController(TelaTurma view) {
       view.setVisible(true);
    }   
}
