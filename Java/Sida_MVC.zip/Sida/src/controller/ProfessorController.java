/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ProfessorDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Professor;
import view.TelaProfessor;

public class ProfessorController {

    private TelaProfessor view;
    private ArrayList<Professor> listaBeans;
   
    private int indexTable;
    
    private int op;
    
    public ProfessorController(TelaProfessor view) {
        this.view = view;
        this.view.addBtnPesquisarListener(new BtnPesquisarListener());
        this.view.addTabelaListener(new TableMouseListener());
        this.view.addBtnNovoListener(new BtnNovoListener());
        this.view.addBtnSalvarListener(new BtnSalvarListener());
        this.view.addBtnExcluirListener(new BtnExcluirListener());
        this.view.addBtnCancelarListener(new BtnCancelarListener());
        
        carregaTabela();
        this.view.setVisible(true);
    }
    
 
       
  
    
    private void carregaTabela(){
        try {
                ProfessorDAO dao = new ProfessorDAO();
                System.out.println(view.getTxtPesquisar()+" III");
                listaBeans = dao.consultar(view.getTxtPesquisar());
              
                Vector linhas = new Vector();
                Vector colunas = new Vector();                
                colunas.add("Matricula");
                colunas.add("Nome");
                colunas.add("Formação");
                

                for (Professor bean : listaBeans) {
                    Vector linha = new Vector();
                    linha.add(bean.getMatricula());
                    linha.add(bean.getNome());
                    linha.add(bean.getFormacao());
                    
                    linhas.add(linha);
                }
                          
                DefaultTableModel model = new DefaultTableModel(linhas, colunas);
                view.setTabela(model);
            } catch (Exception ex) {
                System.out.println(ex);
            }
    }
    
    private void atualizaBtn(boolean ok){
        view.btnNovoEnabled(ok);
        view.btnSalvarEnabled(ok);
        view.btnExcluirEnabled(ok);
        view.btnCancelarEnabled(ok);
    }
    
    private void atualizaCampos(boolean ok){
        //view.txtMatriculaEnabled(ok);
        view.txtNomeEnabled(ok);
        view.txtFormacaoEnabled(ok);
    }
    
    private void limpaCampos(){
        view.setTxtMatricula("");
        view.setTxtNome("");
        view.setTxtFormacao("");
    }
    
    private class BtnNovoListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            op = 0;
            atualizaBtn(false);
            view.btnSalvarEnabled(true);
            view.btnCancelarEnabled(true);
            atualizaCampos(true);
        }
        
    }
    
    private class BtnSalvarListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            // verifica se todos os campos estão preenchidos
            if(!view.getTxtNome().trim().isEmpty() &&
                    !view.getTxtFormacao().trim().isEmpty()){
                
                    //caso op seja igual a 0, cadastra o produto
                    if(op  == 0){
                        Professor bean = new Professor();
                        Random gerador = new Random();
                        
                        bean.setMatricula(""+Calendar.getInstance().get(Calendar.YEAR)+gerador.nextInt(9999));
                        bean.setNome(view.getTxtNome());
                        bean.setFormacao(view.getTxtFormacao());
                        
                        
                        try { 
                            ProfessorDAO dao = new ProfessorDAO();
                            boolean ok = dao.cadastrar(bean);
                            if(ok){
                                view.showMsg("Professor cadastrado!");
                                atualizaBtn(false);
                                view.btnNovoEnabled(true);
                                limpaCampos();
                                atualizaCampos(false);
                            }else{
                                view.showMsg("Erro ao cadastrar professor!");
                            }                           
                        } catch (Exception ex) {
                            System.out.println(ex);
                        }
                        
                    //caso seja diferente de 0, atualiza o produto
                        
                    //caso seja diferente de 0, atualiza o produto
                    }else{
                        Professor bean = listaBeans.get(indexTable);
                        //bean.setMatricula(view.getTxtMatricula());
                        bean.setNome(view.getTxtNome());
                        bean.setFormacao(view.getTxtFormacao());        
                   
                try {
                            ProfessorDAO dao = new ProfessorDAO();
                            boolean ok = dao.alterar(bean);
                            if(ok){
                                view.showMsg("Professor atualizado!");
                                atualizaBtn(false);
                                view.btnNovoEnabled(true);
                                limpaCampos();
                                atualizaCampos(false);
                            }else{
                                view.showMsg("Erro ao atualizar professor!");
                            }  
                            
                        } catch (Exception ex) {
                            System.out.println(ex);
                        }
                        
                    }
                    //atualiza a tabela
                    carregaTabela();
            }else{                    
                view.showMsg("Preencha todos os campos!");
            }         
        }
        
    }
    
    private class BtnExcluirListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            int op = JOptionPane.showConfirmDialog(null, "Deseja proseguir?", "Selecione a opção",JOptionPane.YES_NO_OPTION);
            Professor bean = listaBeans.get(indexTable);
        if(op == 0){
            try {
                ProfessorDAO dao = new ProfessorDAO();
                
                boolean ok = dao.excluir(bean.getMatricula());
                if(ok){
                    JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
                    carregaTabela();
                    limpaCampos();
                    atualizaCampos(false);
                    atualizaBtn(false);
                    view.btnNovoEnabled(true);
                }
            } catch (Exception ex) {
                view.showMsg("Erro ao excluir!");
            }
        }
        
        
    }
    }
    
    private class BtnCancelarListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            limpaCampos();
            atualizaCampos(false);
            atualizaBtn(false);
            view.btnNovoEnabled(true);
        }
        
    }
    
    private class BtnPesquisarListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
                        System.out.println(view.getTxtPesquisar()+"aa");
             System.out.println("bb");                
            carregaTabela();        
        }
        
    }
    
    private class TableMouseListener implements MouseListener{
        @Override
        public void mouseClicked(MouseEvent e) {
            indexTable = view.getTableCursor();
            Professor bean = listaBeans.get(indexTable);
            view.setTxtMatricula(bean.getMatricula());
            view.setTxtNome(bean.getNome());
            view.setTxtFormacao(bean.getFormacao()); 
            atualizaBtn(true);
            view.btnNovoEnabled(false);
            atualizaCampos(true);
            
            op = 1;
        }

        @Override
        public void mousePressed(MouseEvent e) {}

        @Override
        public void mouseReleased(MouseEvent e) {}

        @Override
        public void mouseEntered(MouseEvent e) {}

        @Override
        public void mouseExited(MouseEvent e) {}

       
        
    }
    
}
    
   
    

