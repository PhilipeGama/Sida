/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.diagnostico;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.diagnostico.TelaConsultarAlunoDisciplina;
import view.diagnostico.TelaDiagnosticoAluno;

/**
 *
 * @author Aluno
 */
public class DiagnosticoAlunoController {
//    TelaDiagnosticoAluno view;
//   
//    
//    public DiagnosticoAlunoController(TelaDiagnosticoAluno view){
//        this.view = view;
//        this.view.addBtnBuscarAlunoListener(new BtnBuscarAlunoListener());
//        view.setVisible(true);
//    }
//    
//    private class BtnBuscarAlunoListener implements ActionListener{
//        @Override
//        public void actionPerformed(ActionEvent ae) {
//            new ConsultarAlunoDisciplinaController(new TelaConsultarAlunoDisciplina());
//        }
//    }
//    
}
