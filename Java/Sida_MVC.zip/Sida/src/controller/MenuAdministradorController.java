/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TelaAluno;
import view.TelaCurso;
import view.TelaDisciplina;
import view.TelaMenuAdministrador;
import view.TelaProfessor;
import view.TelaTurma;

/**
 *
 * @author Aluno
 */
public class MenuAdministradorController {
    TelaMenuAdministrador view;

    public MenuAdministradorController(TelaMenuAdministrador view) {
        this.view = view;
        view.setBtnAluno(new aluno());
        view.setBtnCurso(new curso());
        view.setBtnProfessor(new professor());
        view.setBtnDisciplina(new disciplina());
        view.setBtnTurma(new turma());
        view.setVisible(true);
        
    }
    
    class aluno implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            new AlunoController(new TelaAluno()); 
            view.closeView();
        }
        
    }
    class curso implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            new CursoController(new TelaCurso()); 
            view.closeView();
        }
        
    }
    class professor implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            new ProfessorController(new TelaProfessor());
            view.closeView();
        }
        
    }
    class disciplina implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            new DisciplinaController(new TelaDisciplina());
            view.closeView();
        }
        
    }
    class turma implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
             new TurmaController(new TelaTurma());
             view.closeView();
        }
        
    }
    
    
}
