/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.CursoDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import model.Curso;
import view.TelaListaCurso;

/**
 *
 * @author Aluno
 */
public class ListaCursoController {
  private TelaListaCurso view;
    private ArrayList<Curso> listaBeans;
    DisciplinaController controller;
    private int index;
    private int op;
    
    
    public ListaCursoController(TelaListaCurso view, DisciplinaController controller) {
        this.view = view;
        this.controller = controller;
        this.view.addBtnPesquisarListener(new buscar());
        this.view.addTableListener(new TblMouseListener());
        carregaTabela();
        this.view.setVisible(true);
    }
    
     private void carregaTabela(){
        try {
                CursoDAO dao = new CursoDAO();
                
                listaBeans = dao.consultarDescricao(view.getTxtPesquisar());
                
                Vector linhas = new Vector();
                Vector colunas = new Vector();                
                colunas.add("Sigla");
                colunas.add("Descrição");
                

                for (Curso bean : listaBeans) {
                    Vector linha = new Vector();
                    linha.add(bean.getSigla());
                    linha.add(bean.getDescricao());
                    linhas.add(linha);
                }
                          
                DefaultTableModel model = new DefaultTableModel(linhas, colunas);
                view.setTblDados(model);
            } catch (Exception ex) {
                Logger.getLogger(DisciplinaController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
     class buscar implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            carregaTabela();
        }
         
     }
     
     class TblMouseListener implements MouseListener{

        @Override
        public void mouseClicked(MouseEvent e) {
            if (e.getClickCount() == 2) {
                int index = view.getTblRow();
                Curso curso = listaBeans.get(index);
                controller.adicionarListaBeans3(curso);
                
                
                controller.adicionarComboBox(curso.getSigla());
                //view.closeView();
                
            }
        }
        @Override
        public void mousePressed(MouseEvent e) {
            
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            
        }

        @Override
        public void mouseExited(MouseEvent e) {
           
        }       
    }
}
