/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
/**
 *
 * @author Philipe
 */
public class Disciplina {
    private String sigla;
    private String descricao;
    private double cargahoraria;
    private Curso curso;

    public Disciplina() {
        this.curso = new Curso();
    }

    public Disciplina(String sigla, String descricao, double cargahoraria) {
        this.sigla = sigla;
        this.descricao = descricao;
        this.cargahoraria = cargahoraria;
        
    }

    
    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getCargahoraria() {
        return cargahoraria;
    }

    public void setCargahoraria(double cargahoraria) {
        this.cargahoraria = cargahoraria;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "Disciplina{" + "sigla=" + sigla + ", descricao=" + descricao + ", cargahoraria=" + cargahoraria + ", curso=" + curso + '}';
    }

    
    
   
  
}
