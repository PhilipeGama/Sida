/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import connection.FabricaConexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import model.DisciplinaCurso;


/**
 *
 * @author Philipe
 */
public class DisciplinaCursoDAO {
      private Connection connection;
    public DisciplinaCursoDAO() throws Exception {
        this.connection = FabricaConexao.getConnection();
    }
    
    public boolean addDisciplina(DisciplinaCurso bean){
        String sql = "INSERT INTO Disciplina_Curso VALUES (?,?);";       
        try{
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(2, bean.getDissigla());
            ps.setString(1, bean.getCursigla());
        
            ps.execute();
            connection.close();
            return true;
        }catch(Exception e){
            return false;
        }
        
    }
}
