/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc;

import controller.MenuProfessorController;
import view.TelaMenuProfessor;

/**
 *
 * @author Philipe
 */
public class RunTelaMenuProfessor {
    public static void main(String[] args) {
        new MenuProfessorController(new TelaMenuProfessor());
    }
}
