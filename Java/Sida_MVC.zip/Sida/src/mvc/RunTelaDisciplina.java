/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc;

import view.TelaDisciplina;
import controller.DisciplinaController;

/**
 *
 * @author Philipe
 */
public class RunTelaDisciplina {
    public static void main(String[] args) {
       new DisciplinaController(new TelaDisciplina());
    }
}
