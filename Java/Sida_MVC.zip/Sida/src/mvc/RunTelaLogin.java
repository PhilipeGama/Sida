/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc;

import controller.LoginController;
import view.TelaLogin;

/**
 *
 * @author Philipe
 */
public class RunTelaLogin {
    public static void main(String[] args) {
        new LoginController(new TelaLogin());
    }
}
